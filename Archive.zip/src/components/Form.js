import React, { useState } from "react";

const Form = (props) => {
    const {inpiuts, setInputs} = props;

    const [firstName, setfirstName] = useState("");
    const [firstNameError, setfirstNameError] = useState("");

    const [lastName, setLastName] = useState("");
    const [lastNameError, setLastNameError] = useState("");

    const [email, setEmail] = useState("");
    const [emailError, setEmailError] =  useState("");

    const [pw, setPw] = useState("");
    const [pwError, setPwError] = useState("");

    const [confirmPw, setConfirmPw] = useState("");
    const [ConfirmPwError, setConfirmPwError] = useState("");


    const [hasBeenSubmitted, setHasBeenSubmitted] = useState(false);


    const onChange = e => {
        setInputs({
            ...inpiuts,
            [e.target.name]: e.target.value
        });
    };

    const submitHandler =  e => {
        e.preventDefault();
        const newUser = { firstName, lastName, email, pw, confirmPw };
        setHasBeenSubmitted(true);
    };

    const handleFirstName = e => {
        setfirstName(e.target.value);
        if(e.target.value.length < 2){
            setfirstNameError("First name must be at least 2 characters")
        }
    };

    const handleLastName = e => {
        setLastNameError(e.target.value);
        if(e.target.value.length < 2){
            setLastNameError("Last name must be at least 2 characters")
        }
    };

    const handleEmail = e => {
        setEmailError(e.target.value);
        if (e.target.value.length < 2){
            setEmailError("Email must be at least 2 characters")
        }
    };

    const handlePw = e => {
        setPwError(e.target.value);
        if (e.target.value.length < 8){
            setPwError("Password must be at least 8 characters")
        }
    };

    const handleConfirmPw = e => {
        setConfirmPwError(e.target.value);
        if (e.target.value.lengt < 1){
            setConfirmPwError("Password must match")
        }
    };

    return(
        <form onSubmit = { submitHandler }>
            <div>
                <label htmlFor="firstName">First Name</label>
                <input type="text" name="firstName" onChange ={ handleFirstName } />
                {
                    firstNameError ?
                    <p> { firstNameError } </p> :
                    ''
                }
            </div>

            <div>
                <label htmlFor="lastName">Last Name</label>
                <input type="text" name="lastName" onChange ={ handleLastName} />
                {
                    lastNameError ?
                    <p> {lastNameError } </p> :
                    ''
                }
            </div>

            <div>
                <label htmlFor="email">Email</label>
                <input type="text" name="email" onChange ={ handleEmail } />
                {
                    emailError ?
                    <p> {emailError } </p> :
                    ''
                }
            </div>

            <div>
                <label htmlFor="pw">Password</label>
                <input type="password" name="pw" onChange ={ handlePw } />
                {
                    pwError ?
                    <p> {pwError } </p> :
                    ''
                }
            </div>

            <div>
                <label htmlFor="confirmPw">Confirm Password</label>
                <input type="password" name="confirmPw" onChange ={ handleConfirmPw } />
            </div>

            <input type="submit" value="Submit" />
        </form>
    )
}

export default Form;

// -rafce-
// import React from 'react'

// const form = () => {
//     return (
//         <div>
            
//         </div>
//     )
// }

// export default form
